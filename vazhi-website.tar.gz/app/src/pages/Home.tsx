import Nav from '../sections/Nav';
import Hero from '../sections/Hero';
import Atlas from '../sections/Atlas';
import Destinations from '../sections/Destinations';
import Heritage from '../sections/Heritage';
import Journeys from '../sections/Journeys';
import Stories from '../sections/Stories';
import Interests from '../sections/Interests';
import Recent from '../sections/Recent';
import Footer from '../sections/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-page text-parch">
      <Nav />
      <main>
        <Hero />
        <Atlas />
        <Destinations />
        <Heritage />
        <Journeys />
        <Stories />
        <Interests />
        <Recent />
      </main>
      <Footer />
    </div>
  );
}
