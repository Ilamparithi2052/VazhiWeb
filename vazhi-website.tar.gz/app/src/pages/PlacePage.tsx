import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router';
import PageShell from '../components/PageShell';
import { IMG } from '../data';
import { ui } from '../components/Icons';
import { useLang } from '../i18n';
import { locPlace } from '../content-ta';
import { isSaved, pushRecent, toggleSaved } from '../lib/profile';

export default function PlacePage() {
  const { placeId = '' } = useParams();
  const { lang, t } = useLang();
  const p = locPlace(placeId, lang);
  const [saved, setSaved] = useState(() => isSaved(placeId));

  useEffect(() => {
    if (p) pushRecent(placeId);
    setSaved(isSaved(placeId));
  }, [placeId, p]);

  if (!p) {
    return (
      <PageShell crumbs={[{ label: t('crumb.home'), to: '/' }, { label: t('crumb.notFound') }]}>
        <div className="mx-auto max-w-[1280px] px-5 py-24 md:px-8">
          <h1 className="font-display text-4xl text-parchbright">{t('place.notFound')}</h1>
          <Link to="/" className="mt-4 inline-block text-sm text-bronze">{t('place.back')}</Link>
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell
      crumbs={[
        { label: t('crumb.home'), to: '/' },
        { label: t('crumb.destinations'), to: '/destinations' },
        { label: p.country, to: `/destinations/${p.destId}` },
        { label: p.name },
      ]}
    >
      {/* hero */}
      <div className="mx-auto mt-6 max-w-[1280px] px-5 md:px-8">
        <div className="card-ring relative overflow-hidden rounded-2xl">
          <img src={IMG(p.img)} alt={p.name} className="h-[52vh] min-h-[340px] w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#120d08]/90 via-[#120d08]/40 to-[#120d08]/10" />
          <button
            onClick={() => setSaved(toggleSaved(placeId))}
            aria-pressed={saved}
            className={`absolute right-5 top-5 flex items-center gap-2 rounded-full px-4 py-2 text-[0.66rem] font-semibold uppercase tracking-[0.18em] backdrop-blur-sm transition-all md:right-8 md:top-8 ${
              saved
                ? 'bg-bronze text-bronzeink shadow-lg'
                : 'bg-[#120d08]/60 text-[#e8c07a] ring-1 ring-[#e8c07a]/40 hover:bg-[#120d08]/80'
            }`}
          >
            {ui.bookmark({ className: 'h-3.5 w-3.5' })}
            {saved ? t('place.saved') : t('place.save')}
          </button>
          <div className="absolute inset-x-0 bottom-0 p-6 md:p-10">
            <div className="flex items-center gap-3 text-[0.68rem] font-medium uppercase tracking-[0.24em] text-[#e8c07a]">
              <span>{t(`type.${p.type}`)}</span>
              <span className="text-[#b3a28b]">·</span>
              <span className="flex items-center gap-1.5 text-[#ded2bd]">
                {ui.pin({ className: 'h-3 w-3' })} {p.region} · {p.country}
              </span>
            </div>
            <h1 className="font-display mt-3 text-[3rem] leading-[1.05] text-[#f8f1e2] md:text-[4.6rem]">{p.name}</h1>
          </div>
        </div>
      </div>

      {/* body */}
      <div className="mx-auto grid max-w-[1280px] gap-12 px-5 py-12 md:px-8 lg:grid-cols-[1fr_320px]">
        <article>
          <p className="font-display border-l-2 border-bronze/60 pl-5 text-[1.25rem] italic leading-relaxed text-lede">
            {p.summary}
          </p>
          {p.sections.map((s) => (
            <section key={s.heading} className="mt-10">
              <h2 className="font-display text-[1.7rem] text-parchbright">{s.heading}</h2>
              <div className="mt-1 h-px w-12 bg-bronze/50" />
              {s.body.map((para, i) => (
                <p key={i} className="mt-4 text-[0.95rem] leading-[1.85] text-bodycopy">
                  {para}
                </p>
              ))}
            </section>
          ))}
        </article>

        {/* facts sidebar */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <div className="card-ring rounded-xl bg-surf p-6">
            <p className="eyebrow mb-4">{t('place.glance')}</p>
            <dl>
              {p.facts.map((f) => (
                <div key={f.label} className="flex justify-between gap-4 border-b border-bronze/10 py-2.5 last:border-0">
                  <dt className="text-[0.7rem] uppercase tracking-[0.14em] text-muted2">{f.label}</dt>
                  <dd className="text-right text-[0.8rem] text-parch">{f.value}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="mt-6">
            <p className="eyebrow mb-3">{t('place.related')}</p>
            <div className="space-y-3">
              {p.related.map((rid) => {
                const r = locPlace(rid, lang);
                if (!r) return null;
                return (
                  <Link key={rid} to={`/place/${rid}`} className="group flex items-center gap-3 rounded-lg p-1 transition-colors hover:bg-surf">
                    <img src={IMG(r.img)} alt={r.name} className="card-ring h-14 w-20 rounded-md object-cover" />
                    <div>
                      <p className="text-sm text-parch transition-colors group-hover:text-bronze">{r.name}</p>
                      <p className="text-[0.7rem] text-muted2">{r.region}</p>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </aside>
      </div>
    </PageShell>
  );
}
