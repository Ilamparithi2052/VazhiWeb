import { Link } from 'react-router';
import PageShell from '../components/PageShell';
import { IMG, stories } from '../data';
import { useLang } from '../i18n';
import { storiesTa } from '../content-ta';

export default function StoriesIndex() {
  const { lang, t } = useLang();
  return (
    <PageShell crumbs={[{ label: t('crumb.home'), to: '/' }, { label: t('crumb.stories') }]}>
      <div className="mx-auto max-w-[1280px] px-5 py-10 md:px-8">
        <p className="eyebrow mb-3">{t('sect.stories.eyebrow')}</p>
        <h1 className="font-display text-[2.4rem] text-parchbright md:text-[3rem]">{t('sect.stories.title')}</h1>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-mutedw">
          {t('storiesindex.blurb')}
        </p>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {stories.map((s) => (
            <Link key={s.id} to={`/stories/${s.id}`} className="group">
              <div className="card-ring overflow-hidden rounded-xl">
                <img
                  src={IMG(s.img)}
                  alt={s.title}
                  loading="lazy"
                  className="h-[200px] w-full object-cover transition-transform duration-700 group-hover:scale-[1.06]"
                />
              </div>
              <p className="mt-4 text-[0.62rem] uppercase tracking-[0.24em] text-bronze">{t(`tag.${s.tag}`)}</p>
              <h3 className="font-display mt-1.5 text-[1.4rem] leading-snug text-parch transition-colors group-hover:text-bronze">
                {(lang === 'ta' ? storiesTa[s.id]?.title : undefined) ?? s.title}
              </h3>
              <p className="mt-1.5 text-[0.72rem] text-muted2">{(lang === 'ta' ? storiesTa[s.id]?.time : undefined) ?? s.time}</p>
            </Link>
          ))}
        </div>
      </div>
    </PageShell>
  );
}
