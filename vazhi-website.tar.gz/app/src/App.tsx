import { Routes, Route } from 'react-router'
import { LangProvider } from './i18n'
import Home from './pages/Home'
import PlacePage from './pages/PlacePage'
import DestinationsIndex from './pages/DestinationsIndex'
import DestinationPage from './pages/DestinationPage'
import StatePage from './pages/StatePage'
import DistrictPage from './pages/DistrictPage'
import StoriesIndex from './pages/StoriesIndex'
import StoryPage from './pages/StoryPage'
import AboutPage from './pages/AboutPage'
import ScrollToTop from './components/ScrollToTop'

export default function App() {
  return (
    <LangProvider>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/place/:placeId" element={<PlacePage />} />
        <Route path="/destinations" element={<DestinationsIndex />} />
        <Route path="/destinations/:destId" element={<DestinationPage />} />
        <Route path="/destinations/:destId/states/:stateId" element={<StatePage />} />
        <Route path="/destinations/:destId/states/:stateId/:districtId" element={<DistrictPage />} />
        <Route path="/stories" element={<StoriesIndex />} />
        <Route path="/stories/:storyId" element={<StoryPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </LangProvider>
  )
}
