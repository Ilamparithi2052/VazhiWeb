import { useState } from 'react';
import { Link } from 'react-router';
import { ui } from '../components/Icons';
import Reveal from '../components/Reveal';
import { useLang, useThemeValue } from '../i18n';

const columns: { head: string; items: string[] }[] = [
  { head: 'Explore', items: ['All Places', 'Map', 'Categories', 'Recently Added'] },
  { head: 'Destinations', items: ['Countries', 'States', 'Cities', 'Regions'] },
  { head: 'Heritage', items: ['Temples', 'Forts', 'Caves', 'Archaeology'] },
  { head: 'Journeys', items: ['My Journeys', 'Road Trips', 'Pilgrimages', 'Treks'] },
  { head: 'Stories', items: ['Essays', 'Field Notes', 'Photo Essays', 'Interviews'] },
  { head: 'More', items: ['About', 'Guidelines', 'Contact'] },
];

function TempleSkyline({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 320 120"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {/* gopuram */}
      <path d="M36 116 V96 h10 V84 h8 V70 h8 V56 h8 V40 h8 V26 h8 V12 h6 V4 h4 V12 h6 V26 h8 V40 h8 V56 h8 V70 h8 V84 h8 V96 h10 v20" />
      <path d="M70 116 v-14 a10 10 0 0 1 20 0 v14" />
      <path d="M52 96 h56 M60 84 h40 M68 70 h24 M76 56 h8 M76 40 h8 M84 26 h12" opacity="0.55" />
      {/* mandapa */}
      <path d="M140 116 V100 h12 V88 h44 v12 h12 v16" />
      <path d="M152 88 l16 -10 h12 l16 10" />
      <path d="M174 78 v-8 m-4 0 h8" />
      <path d="M160 116 v-10 m20 10 v-10 m20 10 v-10" opacity="0.55" />
      {/* small shrine */}
      <path d="M222 116 V104 h10 V94 l10 -8 10 8 v10 h10 v12" />
      <path d="M242 86 v-6 m-3 0 h6" />
      {/* trees */}
      <path d="M18 116 v-12 m0 0 c-6 0 -9 -4 -9 -8 c4 0 6 1 9 4 c0 -6 3 -10 8 -10 c0 5 -2 8 -6 10 m4 4 c3 -3 6 -4 10 -3 c-1 4 -4 7 -10 7" />
      <path d="M286 116 v-14 m0 0 c-7 0 -10 -5 -10 -9 c5 0 7 2 10 5 c0 -7 3 -11 9 -11 c0 6 -2 9 -7 11 m5 5 c4 -3 8 -5 12 -4 c-1 5 -5 8 -12 8" />
      <path d="M4 116 H316" />
    </svg>
  );
}

export default function Footer() {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  const { t } = useLang();
  const theme = useThemeValue();

  return (
    <footer className="relative overflow-hidden border-t border-bronze/25 bg-footbg">
      {/* subscribe */}
      <div className="mx-auto max-w-[1280px] px-5 pb-14 pt-16 md:px-8">
        <Reveal>
          <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
            <div>
              <h2 className="font-display text-[2rem] text-parchbright md:text-[2.4rem]">{t('footer.join')}</h2>
              <p className="mt-2 max-w-sm text-sm leading-relaxed text-soft">
                {t('footer.sub')}
              </p>
            </div>
            {done ? (
              <p className="font-display text-xl text-bronze">
                {t('footer.done')}
              </p>
            ) : (
              <form
                className="card-ring flex w-full max-w-md items-center rounded-full bg-surf p-1.5"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (email.trim()) setDone(true);
                }}
              >
                <span className="pl-4 text-muted2">{ui.mail({ className: 'h-4 w-4' })}</span>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={t('footer.emailPh')}
                  className="w-full bg-transparent px-3 py-2.5 text-sm text-parch placeholder-muted2 outline-none"
                />
                <button
                  type="submit"
                  className="shrink-0 rounded-full bg-bronze px-6 py-2.5 text-[0.66rem] font-semibold uppercase tracking-[0.2em] text-page transition-transform hover:scale-[1.03]"
                >
                  {t('footer.subscribe')}
                </button>
              </form>
            )}
          </div>
        </Reveal>
      </div>

      {/* link columns */}
      <div className="border-t border-bronze/20">
        <div className="mx-auto grid max-w-[1280px] gap-10 px-5 py-14 md:grid-cols-[1.4fr_repeat(6,1fr)] md:px-8">
          <div>
            <img
              src="/img/final/logo-black.png"
              alt="வழி — Vazhi"
              className="h-20 w-auto object-contain"
              style={{ filter: theme === 'light' ? 'none' : 'invert(0.92) sepia(0.18)' }}
            />
            <p className="mt-3 max-w-[220px] text-xs leading-relaxed text-muted2">
              {t('footer.blurb')}
            </p>
            <div className="mt-5 flex gap-3 text-muted2">
              {[ui.globe, ui.mail, ui.bookmark].map((Icon, i) => (
                <a
                  key={i}
                  href="#top"
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-bronze/20 transition-colors hover:border-bronze/60 hover:text-bronze"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
          {columns.map((c) => (
            <div key={c.head}>
              <p className="mb-4 text-[0.62rem] font-semibold uppercase tracking-[0.24em] text-mutedw">{t(`col.${c.head}`)}</p>
              <ul className="space-y-2.5">
                {c.items.map((it) => (
                  <li key={it}>
                    {it === 'About' ? (
                      <Link to="/about" className="text-[0.8rem] text-soft transition-colors hover:text-bronze">
                        {it}
                      </Link>
                    ) : (
                      <a href="#top" className="text-[0.8rem] text-soft transition-colors hover:text-bronze">
                        {it}
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* skyline + bottom bar */}
      <div className="relative">
        <TempleSkyline className="mx-auto h-24 w-full max-w-xl text-bronze/25" />
        <div className="border-t border-bronze/10">
          <div className="mx-auto flex max-w-[1280px] flex-col items-center justify-between gap-3 px-5 py-6 text-[0.68rem] text-muted2 sm:flex-row md:px-8">
            <p>{t('footer.rights')}</p>
            <p className="tracking-wide">{t('footer.colophon')}</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
