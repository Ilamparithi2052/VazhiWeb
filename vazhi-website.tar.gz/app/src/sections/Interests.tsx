import { interests } from '../data';
import { icons } from '../components/Icons';
import Reveal from '../components/Reveal';
import { useLang } from '../i18n';

const iconKeys = [
  'history', 'architecture', 'art', 'food', 'nature', 'religion', 'fest', 'literature', 'archaeology',
];

export default function Interests() {
  const { t } = useLang();
  return (
    <section className="border-y border-bronze/12 bg-surf3">
      <div className="mx-auto max-w-[1280px] px-5 py-12 md:px-8">
        <p className="eyebrow mb-8">{t('interests.eyebrow')}</p>
        <div className="grid grid-cols-3 gap-y-8 sm:grid-cols-5 md:grid-cols-9">
          {interests.map((k, i) => {
            const Icon = icons[iconKeys[i]];
            return (
              <Reveal key={k} delay={i * 40}>
                <a href="#top" className="group flex flex-col items-center gap-3">
                  <span className="flex h-14 w-14 items-center justify-center rounded-full border border-bronze/20 transition-all duration-300 group-hover:border-bronze/60 group-hover:bg-bronze/8">
                    <Icon className="h-6 w-6 text-mutedw transition-colors group-hover:text-bronze" />
                  </span>
                  <span className="text-center text-[0.66rem] uppercase tracking-[0.14em] text-soft transition-colors group-hover:text-parch">
                    {t(`interest.${k}`)}
                  </span>
                </a>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
